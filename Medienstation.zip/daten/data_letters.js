var data_letters = [{
  key: 'A',
  value: "A"
}, {
  key: "B",
  value: "B"
}, {
  key: ['C', 'D'],
  value: "C-D"
}, {
  key: ['E', 'F'],
  value: "E-F"
}, {
  key: "G",
  value: "G"
}, {
  key: ['H', 'I'],
  value: "H-I"
}, {
  key: "K",
  value: "K"
}, {
  key:"L",
  value: "L"
}, {
  key: "M",
  value: "M"
}, {
  key: "N",
  value: "N"
}, {
  key: "O",
  value: "O"
}, {
  key: ['P', 'Q'],
  value: "P-Q"
}, {
  key: "R",
  value: "R"
}, {
  key: "S",
  value: "S"
}, {
  key: "T",
  value: "T"
}, {
  key: ['U', 'V'],
  value: "U-V"
}, {
  key: "W",
  value: "W"
}, {
  key: ['X', 'Y', 'Z'],
  value: "XYZ"
}];
